#include <bits/stdc++.h>
#define lli long long int
#define endl "\n"
using namespace std;

int main()
{
	int n;
	cin>>n;
	if(n%2==0 and n!=2)
		cout<<"YES";
	else
		cout<<"NO";
}