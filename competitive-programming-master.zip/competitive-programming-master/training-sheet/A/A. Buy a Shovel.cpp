#include <bits/stdc++.h>
# define lli long long int
using namespace std;
int main()
{
	
	
	
return 0;	
}
