while True:
	try:
		test = 10
		while test:
			test -= 1
			n = int(input())
			more = int(input())
			x = (n + more)//2
			y = x - more
			print(x)
			print(y)
		
		
		
		
		
		
		
	except:
		break