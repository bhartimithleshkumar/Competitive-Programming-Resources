#include <bits/stdc++.h>
#define lli long long int
using namespace std;


int main() {
	int t;
	cin>>t;
	while(t--)
	{
		lli n,a = 192,d=250;
		cin>>n;
		cout<<a + (n-1)*d<<endl;
	}
	
	return 0;
}