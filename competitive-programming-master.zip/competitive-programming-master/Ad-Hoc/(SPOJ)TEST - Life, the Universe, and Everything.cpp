#include <iostream>
using namespace std;

int main() {
	int n;
	while(cin>>n)
	if(n!=42)
	cout<<n<<endl;
	else
	break;
	

	return 0;
}