#include <bits/stdc++.h>
#define lli long long int
#define endl "\n"
using namespace std;

int main()
{
	int n,m;
	cin>>n>>m;
	if(min(n,m)%2 == 1)
		cout<<"Akshat";
	else
 		cout<<"Malvika";
	return 0;
}